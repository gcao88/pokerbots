struct Action {
    float r = 0;
    float s = 0.001; 
    float prob = -1; 

    Action(float prob) : prob(prob) {}
};
