struct Action {
    float r = 0;
    float s = 0; 
    float prob = -1; 

    Action(float prob) : prob(prob) {}
};
